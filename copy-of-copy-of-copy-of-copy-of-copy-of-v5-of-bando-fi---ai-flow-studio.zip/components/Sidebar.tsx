import React from 'react';
import type { NodeTemplate } from '../types';
import { MODULE_CATEGORIES, getModulesByCategory } from '../services/moduleLoader';

interface SidebarProps {
  onDragStart: (event: React.DragEvent<HTMLDivElement>, template: NodeTemplate) => void;
  nodeTemplates: NodeTemplate[];
  onOpenCreateModal: () => void;
}

const DraggableNode: React.FC<{ template: NodeTemplate; onDragStart: SidebarProps['onDragStart'] }> = ({ template, onDragStart }) => (
    <div
      key={template.type}
      className="p-3 border-2 border-dashed border-gray-600 rounded-lg text-center text-gray-300 bg-gray-900/50 hover:bg-green-900/50 hover:border-green-500 hover:text-white transition-all duration-200 cursor-grab"
      draggable
      onDragStart={(event) => onDragStart(event, template)}
    >
      {template.title}
    </div>
);


const Sidebar: React.FC<SidebarProps> = ({ onDragStart, nodeTemplates, onOpenCreateModal }) => {
  return (
    <aside className="absolute top-0 left-0 h-full w-64 bg-black/50 backdrop-blur-md border-r border-green-500/30 p-4 z-20 flex flex-col font-orbitron">
      <h1 className="text-2xl font-bold mb-6">
        <span className="text-pink-400 text-glow-pink">BANDO-FI </span>
        <span className="text-green-400 text-glow-green">AI</span>
      </h1>
      
      <div className='flex-grow flex flex-col min-h-0'>
        <h2 className="text-lg font-semibold text-gray-300 mb-2">Modules</h2>
        <div className="flex-grow flex flex-col gap-4 overflow-y-auto pr-2 pb-4">
          {MODULE_CATEGORIES.map(category => (
            <div key={category}>
              <h3 className="text-sm font-semibold text-green-400/80 mb-2 uppercase tracking-wider">{category}</h3>
              <div className="flex flex-col gap-3">
                {getModulesByCategory(category).map(template => (
                    <DraggableNode key={template.type} template={template} onDragStart={onDragStart} />
                ))}
              </div>
            </div>
          ))}
          {nodeTemplates.length > 0 && (
             <div>
              <h3 className="text-sm font-semibold text-green-400/80 mb-2 uppercase tracking-wider">Custom</h3>
               <div className="flex flex-col gap-3">
                {nodeTemplates.map(template => (
                    <DraggableNode key={template.type} template={template} onDragStart={onDragStart} />
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="mt-4 pt-4 border-t border-green-500/30">
          <h2 className="text-lg font-semibold text-gray-300 mb-2">Create with AI</h2>
          <p className="text-xs text-gray-400 mb-3">Describe a task, and AI will create a new module for you.</p>
          <button
            onClick={onOpenCreateModal}
            className="w-full mt-1 px-4 py-2 flex items-center justify-center gap-2 rounded-md font-semibold text-sm transition-all duration-200 bg-green-600 hover:bg-green-500 text-white shadow-[0_0_10px_#00ff00]"
          >
            Create Custom Module
          </button>
        </div>
      </div>

      <div className="mt-auto text-xs text-gray-500 pt-4">
        <p>Drag modules onto the canvas.</p>
      </div>
    </aside>
  );
};

export default Sidebar;