import React, { useState } from 'react';
import { SpinnerIcon, DownloadIcon } from './icons';
import type { ExecutionLogEntry, EmergenceLog } from '../types';

interface IOPanelProps {
  input: string;
  setInput: (value: string) => void;
  output: string;
  isRunning: boolean;
  executionLog: ExecutionLogEntry[];
  emergenceLog: EmergenceLog | null;
  onDownloadEmergenceLog: () => void;
}

const LogEntry: React.FC<{ entry: ExecutionLogEntry }> = ({ entry }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="border-b border-green-500/20 py-2">
            <div className="flex justify-between items-center cursor-pointer" onClick={() => setIsOpen(!isOpen)}>
                <div className="flex-1">
                    <p className="font-semibold text-green-400">Step {entry.step}: <span className="text-gray-300">{entry.nodeTitle}</span></p>
                    <p className="text-xs text-gray-400 italic mt-1">{entry.summary}</p>
                </div>
                <span className="text-green-400 text-xs transform transition-transform">{isOpen ? '▼' : '▶'}</span>
            </div>
            {isOpen && (
                <div className="mt-2 pl-4 text-xs bg-gray-900/50 p-2 rounded">
                    <p className="font-bold text-gray-400">Input:</p>
                    <pre className="whitespace-pre-wrap break-words text-gray-300 max-h-24 overflow-y-auto">{typeof entry.input === 'object' ? JSON.stringify(entry.input, null, 2) : entry.input}</pre>
                    <p className="font-bold text-gray-400 mt-2">Output:</p>
                    <pre className="whitespace-pre-wrap break-words text-gray-300 max-h-24 overflow-y-auto">{typeof entry.output === 'object' ? JSON.stringify(entry.output, null, 2) : entry.output}</pre>
                </div>
            )}
        </div>
    );
};

const IOPanel: React.FC<IOPanelProps> = ({ input, setInput, output, isRunning, executionLog, emergenceLog, onDownloadEmergenceLog }) => {
  return (
    <div className="absolute top-4 right-4 w-96 z-20 flex flex-col gap-4 font-orbitron max-h-[calc(100vh-2rem)]">
      <div className="bg-black/50 backdrop-blur-md border border-green-500/30 rounded-lg p-4 flex-shrink-0">
        <h2 className="text-lg font-semibold text-green-400/80 mb-2">Input</h2>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter the initial input for the pipeline..."
          className="w-full h-24 p-2 bg-gray-900/50 border border-gray-700 rounded-md text-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors"
          disabled={isRunning}
        />
      </div>
      <div className="bg-black/50 backdrop-blur-md border border-green-500/30 rounded-lg p-4 flex flex-col min-h-0 flex-grow">
        <h2 className="text-lg font-semibold text-green-400/80 mb-2">Final Output</h2>
        <div className="w-full min-h-24 flex-grow p-2 bg-gray-900/50 border border-gray-700 rounded-md text-gray-300 overflow-y-auto whitespace-pre-wrap break-words">
          {isRunning && !output && (
            <div className="flex items-center justify-center h-full text-gray-400">
              <SpinnerIcon />
              <span className="ml-2">Processing...</span>
            </div>
          )}
          {output}
        </div>
        
        {/* Execution Log */}
        {executionLog.length > 0 && (
            <div className="mt-4 border-t border-green-500/30 pt-2">
                 <h3 className="text-md font-semibold text-green-400/80 mb-2">Execution Log</h3>
                 <div className="max-h-48 overflow-y-auto pr-2">
                    {executionLog.map(entry => <LogEntry key={entry.step} entry={entry} />)}
                 </div>
            </div>
        )}

        {/* System Emergence Log */}
        {emergenceLog && (
            <div className="mt-4 border-t border-green-500/30 pt-2">
                 <div className="flex justify-between items-center mb-2">
                    <h3 className="text-md font-semibold text-green-400/80">System Emergence Log</h3>
                    <button onClick={onDownloadEmergenceLog} className="flex items-center gap-1 text-xs px-2 py-1 bg-green-800/50 hover:bg-green-700/50 rounded">
                        <DownloadIcon />
                        Download
                    </button>
                 </div>
                 <div className="max-h-32 overflow-y-auto text-xs text-gray-400 p-2 bg-gray-900/50 rounded border border-gray-700">
                    <p className="font-bold text-gray-300 mb-1">Pipeline Order:</p>
                    <p className="mb-2">{emergenceLog.executionOrder.join(' → ')}</p>
                    <p className="font-bold text-gray-300 mb-1">Emergent Capability Analysis:</p>
                    <p>{emergenceLog.emergenceSummary}</p>
                 </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default IOPanel;
