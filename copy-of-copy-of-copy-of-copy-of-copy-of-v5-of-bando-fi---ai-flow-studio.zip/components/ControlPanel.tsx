

import React, { useState, useRef, useEffect } from 'react';
import { PlayIcon, SaveIcon, LoadIcon, TrashIcon, SpinnerIcon, MenuIcon, GroupIcon, UngroupIcon, DownloadIcon } from './icons';
import type { Pipeline, Group } from '../types';

interface ControlPanelProps {
  onRun: () => void;
  onSave: () => void;
  onLoad: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onClear: () => void;
  onGroup: () => void;
  onUngroup: () => void;
  onDownloadReport: () => void;
  isRunning: boolean;
  templates: { name: string, pipeline: Pipeline }[];
  onLoadTemplate: (pipeline: Pipeline) => void;
  selectedIds: string[];
  groups: Group[];
}

// FIX: Moved Button and MenuItem components outside of ControlPanel and used explicit interfaces for props.
// This prevents them from being redefined on every render and can fix subtle typing issues.
interface ButtonProps {
  onClick?: () => void;
  children: React.ReactNode;
  disabled?: boolean;
  className?: string;
}

const Button = ({ onClick, children, disabled = false, className = '' }: ButtonProps) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`px-4 py-2 flex items-center gap-2 rounded-md font-semibold text-sm transition-all duration-200 ${className} disabled:opacity-50 disabled:cursor-not-allowed`}
  >
    {children}
  </button>
);

interface MenuItemProps {
  children: React.ReactNode;
  onClick: () => void;
}

const MenuItem = ({ children, onClick }: MenuItemProps) => (
  <button onClick={onClick} className="w-full text-left flex items-center gap-3 px-3 py-2 text-sm text-gray-300 hover:bg-green-700/50 rounded-md">
    {children}
  </button>
);

const ControlPanel: React.FC<ControlPanelProps> = ({ 
    onRun, onSave, onLoad, onClear, onGroup, onUngroup, onDownloadReport,
    isRunning, templates, onLoadTemplate, selectedIds, groups 
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isTemplateMenuOpen, setIsTemplateMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const handleLoadClick = () => {
    fileInputRef.current?.click();
    setIsMenuOpen(false);
  };

  const handleSaveClick = () => {
    onSave();
    setIsMenuOpen(false);
  }

  const handleLoadTemplateClick = (pipeline: Pipeline) => {
    onLoadTemplate(pipeline);
    setIsMenuOpen(false);
    setIsTemplateMenuOpen(false);
  }

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
        setIsTemplateMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const isGroupSelected = selectedIds.length === 1 && groups.some(g => g.id === selectedIds[0]);
  const canGroup = selectedIds.length > 1 && !selectedIds.some(id => groups.some(g => g.id === id));


  return (
    <div ref={menuRef} className="absolute top-4 right-[25rem] z-30 flex gap-3 p-2 bg-black/50 backdrop-blur-md border border-green-500/30 rounded-lg font-orbitron">
      {/* Main Controls */}
      <Button
        onClick={onRun}
        disabled={isRunning}
        className="bg-green-600 hover:bg-green-500 text-white shadow-[0_0_10px_#00ff00]"
      >
        {isRunning ? <SpinnerIcon /> : <PlayIcon />}
        {isRunning ? 'Running...' : 'Run'}
      </Button>

      {canGroup && (
        <Button onClick={onGroup} className="bg-blue-600 hover:bg-blue-500 text-white">
            <GroupIcon /> Group
        </Button>
      )}
       {isGroupSelected && (
        <Button onClick={onUngroup} className="bg-blue-600 hover:bg-blue-500 text-white">
            <UngroupIcon /> Ungroup
        </Button>
      )}

      <Button onClick={onClear} className="bg-red-700 hover:bg-red-600 text-white">
        <TrashIcon />
      </Button>
      
      {/* Menu Button */}
      <div className="relative">
        <Button onClick={() => setIsMenuOpen(!isMenuOpen)} className="bg-gray-600 hover:bg-gray-500 text-white">
            <MenuIcon />
        </Button>
        {/* Expandable Menu */}
        {isMenuOpen && (
            <div className="absolute top-full right-0 mt-2 w-64 bg-gray-900/90 backdrop-blur-lg border border-green-500/30 rounded-lg p-2 shadow-2xl">
                <MenuItem onClick={onDownloadReport}>
                    <DownloadIcon /> Download Report
                </MenuItem>
                <div className="my-1 border-t border-green-500/20"></div>
                <MenuItem onClick={handleSaveClick}>
                    <SaveIcon /> Save Project
                </MenuItem>
                <MenuItem onClick={handleLoadClick}>
                    <LoadIcon /> Load Project
                </MenuItem>
                <div className="my-1 border-t border-green-500/20"></div>

                {/* Template Submenu */}
                <div className="relative">
                    <button 
                        onMouseEnter={() => setIsTemplateMenuOpen(true)}
                        className="w-full text-left flex items-center justify-between gap-3 px-3 py-2 text-sm text-gray-300 hover:bg-green-700/50 rounded-md"
                    >
                       <span>Load Emergent Template</span>
                       <span className="text-xs">▶</span>
                    </button>
                    {isTemplateMenuOpen && (
                        <div onMouseLeave={() => setIsTemplateMenuOpen(false)} className="absolute left-full -top-2 ml-2 w-72 bg-gray-900/90 backdrop-blur-lg border border-green-500/30 rounded-lg p-2 shadow-2xl">
                           <p className="text-xs text-gray-400 px-3 pb-2">Load a pre-built pipeline.</p>
                           <div className="max-h-64 overflow-y-auto">
                                {templates.map(template => (
                                    <button 
                                        key={template.name} 
                                        onClick={() => handleLoadTemplateClick(template.pipeline)}
                                        className="w-full text-left text-sm text-gray-300 hover:bg-green-700/50 rounded-md p-3"
                                    >
                                        <p className="font-semibold">{template.name}</p>
                                        <p className="text-xs text-gray-400">{template.pipeline.nodes.length-2} Modules</p>
                                    </button>
                                ))}
                           </div>
                        </div>
                    )}
                </div>
            </div>
        )}
      </div>

      <input
        type="file"
        ref={fileInputRef}
        onChange={onLoad}
        className="hidden"
        accept=".json"
      />
    </div>
  );
};

export default ControlPanel;