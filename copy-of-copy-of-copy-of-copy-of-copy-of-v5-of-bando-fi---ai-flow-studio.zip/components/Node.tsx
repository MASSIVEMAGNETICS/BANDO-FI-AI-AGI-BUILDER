import React, { MouseEvent } from 'react';
import type { AINode } from '../types';
import { TrashIcon, SpinnerIcon } from './icons';

interface NodeProps {
  node: AINode;
  isSelected: boolean;
  onDelete: (nodeId: string) => void;
  onUpdateData: (nodeId: string, data: Partial<AINode['data']>) => void;
  onResizeStart: (e: MouseEvent, nodeId: string) => void;
}

const Node: React.FC<NodeProps> = ({ node, isSelected, onDelete, onResizeStart }) => {
  const { id, title, data, hasInput, hasOutput, inputType, outputType, type, width = 256, height = 150 } = node;
  const { status, error } = data;

  const statusColors = {
    idle: 'border-gray-600',
    running: 'border-blue-500 shadow-[0_0_10px_#3b82f6]',
    success: 'border-green-500 shadow-[0_0_10px_#22c55e]',
    error: 'border-red-500 shadow-[0_0_10px_#ef4444]',
  };
  
  const selectionClass = isSelected ? 'border-pink-500 shadow-[0_0_15px_#ec4899]' : statusColors[status];

  const isIO = type === 'input' || type === 'output';

  const handleResizeMouseDown = (e: MouseEvent) => {
    e.stopPropagation();
    onResizeStart(e, id);
  };

  return (
    <div
      id={id}
      data-element-type="node"
      className={`absolute rounded-lg bg-gray-900 shadow-xl transition-shadow duration-300 border-2 flex flex-col ${selectionClass}`}
      style={{ left: node.position.x, top: node.position.y, width: `${width}px`, height: `${height}px` }}
    >
      {hasInput && (
        <div data-handle-type="target" data-node-id={id} className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-gray-700 rounded-full border-2 border-gray-900 hover:bg-green-500 cursor-crosshair">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-gray-500" />
            <div className="absolute -left-20 top-1/2 -translate-y-1/2 text-xs text-gray-400 w-16 text-right">{inputType}</div>
        </div>
      )}

      <div className={`flex items-center justify-between p-2 rounded-t-lg bg-gray-800 border-b-2 ${selectionClass} cursor-move grab-handle flex-shrink-0`}>
        <h3 className="font-bold text-sm truncate" title={title}>{title}</h3>
        {!isIO && (
            <button onClick={() => onDelete(id)} className="text-gray-400 hover:text-red-500">
                <TrashIcon />
            </button>
        )}
      </div>

      <div className="p-3 text-sm text-gray-300 flex-grow flex items-center justify-center min-h-0">
        {status === 'running' && (
            <div className="flex items-center justify-center p-4">
                <SpinnerIcon />
            </div>
        )}
        {status === 'error' && <p className="text-red-400 text-xs break-words">{error}</p>}
        {status === 'success' && data.output && (
             <p className="text-xs text-gray-400 break-words max-h-full overflow-y-auto">
                Output: <span className="text-gray-200">{JSON.stringify(data.output).length > 100 ? JSON.stringify(data.output).substring(0, 100) + '...' : JSON.stringify(data.output)}</span>
             </p>
        )}
         {isIO && (
             <p className="text-xs text-gray-500 p-4 text-center">
                {type === 'input' ? 'Pipeline starts here' : 'Pipeline ends here'}
             </p>
         )}
      </div>
      
      {hasOutput && (
        <div data-handle-type="source" data-node-id={id} className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-gray-700 rounded-full border-2 border-gray-900 hover:bg-green-500 cursor-crosshair">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-gray-500" />
            <div className="absolute -right-20 top-1/2 -translate-y-1/2 text-xs text-gray-400 w-16 text-left">{outputType}</div>
        </div>
      )}
      
      {!isIO && (
        <div
          onMouseDown={handleResizeMouseDown}
          className="absolute -bottom-2 -right-2 w-4 h-4 bg-gray-600 border-2 border-gray-900 rounded-full cursor-nwse-resize hover:bg-green-500"
        ></div>
      )}
    </div>
  );
};

export default Node;