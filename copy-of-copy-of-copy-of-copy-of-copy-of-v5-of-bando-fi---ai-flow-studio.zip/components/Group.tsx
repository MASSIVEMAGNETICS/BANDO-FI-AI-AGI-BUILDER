import React from 'react';
import type { Group as GroupType } from '../types';
import { TrashIcon, CollapseIcon, ExpandIcon } from './icons';

interface GroupProps {
  group: GroupType;
  children: React.ReactNode;
  isSelected: boolean;
  onToggleCollapse: (groupId: string) => void;
  onDelete: (groupId: string) => void;
}

const Group: React.FC<GroupProps> = ({ group, children, isSelected, onToggleCollapse, onDelete }) => {
  const { id, title, position, width, height, isCollapsed } = group;

  const selectionClass = isSelected ? 'border-pink-500 shadow-[0_0_15px_#ec4899]' : 'border-green-500/30';
  const finalHeight = isCollapsed ? 50 : height;

  return (
    <div
      id={id}
      data-element-type="group"
      className={`absolute rounded-lg bg-black/40 backdrop-blur-sm border-2 transition-all duration-300 ${selectionClass}`}
      style={{ left: position.x, top: position.y, width: `${width}px`, height: `${finalHeight}px`, zIndex: 0 }}
    >
        <div className={`flex items-center justify-between p-2 rounded-t-lg bg-gray-800/50 border-b-2 cursor-move grab-handle flex-shrink-0 ${selectionClass}`}>
            <h3 className="font-bold text-sm truncate" title={title}>{title}</h3>
            <div className="flex items-center gap-2">
                <button onClick={(e) => { e.stopPropagation(); onToggleCollapse(id); }} className="text-gray-400 hover:text-white">
                    {isCollapsed ? <ExpandIcon /> : <CollapseIcon />}
                </button>
                <button onClick={(e) => { e.stopPropagation(); onDelete(id); }} className="text-gray-400 hover:text-red-500">
                    <TrashIcon />
                </button>
            </div>
        </div>
        
        {!isCollapsed && (
            <div className="relative w-full h-full">
                {children}
            </div>
        )}

        {isCollapsed && (
             <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-gray-700 rounded-full border-2 border-gray-900"/>
        )}
        {isCollapsed && (
             <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-gray-700 rounded-full border-2 border-gray-900"/>
        )}

    </div>
  );
};

export default Group;
