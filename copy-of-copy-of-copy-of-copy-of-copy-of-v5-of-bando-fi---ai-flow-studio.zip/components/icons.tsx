
import React from 'react';

const Icon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="1em"
    height="1em"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  />
);

export const PlayIcon: React.FC = () => (
  <Icon>
    <polygon points="5 3 19 12 5 21 5 3" />
  </Icon>
);

export const SaveIcon: React.FC = () => (
  <Icon>
    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
    <polyline points="17 21 17 13 7 13 7 21" />
    <polyline points="7 3 7 8 15 8" />
  </Icon>
);

export const LoadIcon: React.FC = () => (
  <Icon>
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
    <polyline points="17 8 12 3 7 8" />
    <line x1="12" y1="3" x2="12" y2="15" />
  </Icon>
);

export const DownloadIcon: React.FC = () => (
    <Icon>
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
        <polyline points="7 10 12 15 17 10" />
        <line x1="12" y1="15" x2="12" y2="3" />
    </Icon>
);

export const TrashIcon: React.FC = () => (
    <Icon>
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </Icon>
);

export const SpinnerIcon: React.FC = () => (
  <Icon className="animate-spin">
    <line x1="12" y1="2" x2="12" y2="6" />
    <line x1="12" y1="18" x2="12" y2="22" />
    <line x1="4.93" y1="4.93" x2="7.76" y2="7.76" />
    <line x1="16.24" y1="16.24" x2="19.07" y2="19.07" />
    <line x1="2" y1="12" x2="6" y2="12" />
    <line x1="18" y1="12" x2="22" y2="12" />
    <line x1="4.93" y1="19.07" x2="7.76" y2="16.24" />
    <line x1="16.24" y1="7.76" x2="19.07" y2="4.93" />
  </Icon>
);

export const MenuIcon: React.FC = () => (
    <Icon>
        <line x1="3" y1="12" x2="21" y2="12" />
        <line x1="3" y1="6" x2="21" y2="6" />
        <line x1="3" y1="18" x2="21" y2="18" />
    </Icon>
);

export const GroupIcon: React.FC = () => (
    <Icon>
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
        <rect x="8" y="8" width="3" height="3"></rect>
        <rect x="13" y="8" width="3" height="3"></rect>
        <rect x="8" y="13" width="3" height="3"></rect>
    </Icon>
);

export const UngroupIcon: React.FC = () => (
    <Icon>
        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
        <path d="M8 8h3v3H8zM13 8h3v3h-3zM8 13h3v3H8z" stroke="none" fill="currentColor"></path>
        <path d="M17 13.5v-3h-3.5" />
        <path d="M13.5 10.5l4-4" />
    </Icon>
);

export const ExpandIcon: React.FC = () => (
    <Icon>
        <polyline points="15 3 21 3 21 9" />
        <polyline points="9 21 3 21 3 15" />
        <line x1="21" y1="3" x2="14" y2="10" />
        <line x1="3" y1="21" x2="10" y2="14" />
    </Icon>
);

export const CollapseIcon: React.FC = () => (
    <Icon>
        <polyline points="4 14 10 14 10 20" />
        <polyline points="20 10 14 10 14 4" />
        <line x1="14" y1="10" x2="21" y2="3" />
        <line x1="10" y1="14" x2="3" y2="21" />
    </Icon>
);