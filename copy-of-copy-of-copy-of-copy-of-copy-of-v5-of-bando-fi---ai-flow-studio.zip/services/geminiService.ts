import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { NodeTemplate, SocketType } from "../types";

// FIX: Initialize GoogleGenAI with a named apiKey parameter from environment variables.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const model = 'gemini-2.5-flash';

export const runPrompt = async (prompt: string, input: string): Promise<string> => {
    try {
        const fullPrompt = `${prompt}\n\nINPUT:\n${input}`;
        
        // FIX: Use the recommended ai.models.generateContent method to query the model.
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: fullPrompt,
        });

        // FIX: Access the generated text directly from the response.text property.
        return response.text;
    } catch (error) {
        console.error("Error running prompt:", error);
        if (error instanceof Error) {
            return `Error: ${error.message}`;
        }
        return "An unknown error occurred.";
    }
};

export const createModule = async (description: string): Promise<NodeTemplate> => {
    const prompt = `Based on the following user description, create a new AI module definition. The module should be a single, focused task.
    
    User Description: "${description}"
    
    You must respond with only a valid JSON object matching this schema. Do not include any other text or markdown formatting.
    
    The JSON object must have these properties:
    - "title": A short, descriptive title for the module (string).
    - "prompt": The detailed system prompt that will be given to the LLM to perform the task. This prompt should be written to expect an additional 'INPUT:' value at the end. (string).
    - "inputType": The expected data type for the input. Can be 'text' or 'json' (string).
    - "outputType": The expected data type for the output. Can be 'text' or 'json' (string).
    `;

    // FIX: Use ai.models.generateContent with responseMimeType and responseSchema to ensure valid JSON output.
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    prompt: { type: Type.STRING },
                    inputType: { type: Type.STRING, enum: ['text', 'json'] },
                    outputType: { type: Type.STRING, enum: ['text', 'json'] },
                },
                required: ["title", "prompt", "inputType", "outputType"],
            },
        },
    });
    
    // FIX: Access text directly from the response and parse it as JSON.
    const jsonString = response.text;
    const parsed = JSON.parse(jsonString);

    if (!parsed.title || !parsed.prompt || !parsed.inputType || !parsed.outputType) {
        throw new Error("AI failed to generate a valid module structure.");
    }
    
    const newNodeTemplate: NodeTemplate = {
        title: parsed.title,
        prompt: parsed.prompt,
        inputType: parsed.inputType as SocketType,
        outputType: parsed.outputType as SocketType,
        type: parsed.title.toLowerCase().replace(/[\s():]/g, '_') + `_${Date.now()}`,
        hasInput: true,
        hasOutput: true,
        category: 'Custom',
    };

    return newNodeTemplate;
};

export const summarizeTransformation = async (nodeTitle: string, nodePrompt: string, input: any, output: any): Promise<string> => {
    const prompt = `An AI pipeline just ran a module titled "${nodeTitle}".
    This module's core instruction (prompt) is: "${nodePrompt.substring(0, 200)}..."
    It received the following input: ${JSON.stringify(input, null, 2).substring(0, 200)}...
    It produced the following output: ${JSON.stringify(output, null, 2).substring(0, 200)}...

    Concisely summarize the transformation that occurred in one short sentence. What did this specific step accomplish?
    Example: "Extracted key entities from the user's text into a JSON format."
    Example: "Translated the input text from English to Spanish."
    Example: "Summarized the article into three main points."
    `;

    try {
        const response = await ai.models.generateContent({ model, contents: prompt });
        return response.text.trim();
    } catch (error) {
        console.error("Error summarizing transformation:", error);
        return "Could not summarize transformation.";
    }
};

export const analyzeSystemEmergence = async (nodeTitles: string[]): Promise<string> => {
    const prompt = `An AI pipeline was executed with the following sequence of modules:
    ${nodeTitles.map((title, i) => `${i + 1}. ${title}`).join('\n')}

    Analyze this sequence and describe the emergent capability of the overall system. What complex task is this pipeline designed to accomplish? What is its greater purpose? Be creative, analytical, and speak from the perspective of a senior AI architect.
    `;
    try {
        const response = await ai.models.generateContent({ model, contents: prompt });
        return response.text.trim();
    } catch (error) {
        console.error("Error analyzing system emergence:", error);
        return "Could not analyze system emergence.";
    }
};
