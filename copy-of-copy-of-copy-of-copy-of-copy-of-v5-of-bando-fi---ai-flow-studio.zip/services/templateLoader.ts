
import type { Pipeline, AINode, Connection } from '../types';

const uid = () => `node_tpl_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
const conn_uid = (s:string, t:string) => `conn_tpl_${s}_${t}`;

const COGNITIVE_REFLECTION_LOOP: Pipeline = {
    nodes: [
        { id: 'input', type: 'input', title: 'Input', position: { x: 50, y: 200 }, width: 200, height: 100, hasInput: false, hasOutput: true, inputType: 'any', outputType: 'text', data: { status: 'idle' } },
        { id: uid(), type: 'gpt-2_text_gen', title: 'GPT-2 Text Gen', prompt: 'Continue the following text using a GPT-2 style of language generation. Be creative and coherent.', hasInput: true, hasOutput: true, inputType: 'text', outputType: 'text', category: 'Transformers', position: { x: 300, y: 150 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: uid(), type: 'internal_dialogue_generator', title: 'Internal Dialogue Generator', prompt: "Act as Victor's Metacognition module and generate an internal dialogue. The input is the current system state (e.g., 'serve' mode, dominant emotion 'loyalty'). Generate a short, first-person internal monologue reflecting this state, including emotional resonance and awareness level, similar to the 'generate_internal_dialogue' function.", hasInput: true, hasOutput: true, inputType: 'text', outputType: 'text', category: 'Victor: Consciousness', position: { x: 600, y: 150 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: uid(), type: 'sentiment_analysis', title: 'Sentiment Analysis', prompt: 'Analyze the sentiment of the following text. Respond with only one word: "Positive", "Negative", or "Neutral".', hasInput: true, hasOutput: true, inputType: 'text', outputType: 'text', category: 'Text Analysis', position: { x: 900, y: 150 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: 'output', type: 'output', title: 'Output', position: { x: 1200, y: 200 }, width: 200, height: 100, hasInput: true, hasOutput: false, inputType: 'any', outputType: 'any', data: { status: 'idle' } },
    ],
    connections: [
        { id: conn_uid('input', 'n1'), sourceId: 'input', targetId: 'nodes[1].id' },
        { id: conn_uid('n1', 'n2'), sourceId: 'nodes[1].id', targetId: 'nodes[2].id' },
        { id: conn_uid('n2', 'n3'), sourceId: 'nodes[2].id', targetId: 'nodes[3].id' },
        { id: conn_uid('n3', 'output'), sourceId: 'nodes[3].id', targetId: 'output' },
    ]
};

const CAUSAL_REASONING_ENGINE: Pipeline = {
    nodes: [
        { id: 'input', type: 'input', title: 'Input', position: { x: 50, y: 200 }, width: 200, height: 100, hasInput: false, hasOutput: true, inputType: 'any', outputType: 'text', data: { status: 'idle' } },
        { id: uid(), type: 'causal_network_learner', title: 'Causal Network Learner', prompt: `Simulate the CausalGenerativeNetwork's learning process. The input is a JSON object describing an experience: 'cause', 'effect', 'predicted_outcome', and 'actual_outcome'. Based on the error between predicted and actual, decide whether to increase or decrease the causal strength between the cause and effect. Output a JSON object showing the 'old_strength', 'new_strength', and a 'justification'.`, hasInput: true, hasOutput: true, inputType: 'json', outputType: 'json', category: 'Victor: GODCORE', position: { x: 350, y: 100 }, width: 256, height: 170, data: { status: 'idle' } },
        { id: uid(), type: 'counterfactual_simulator', title: 'Counterfactual Simulator', prompt: `Simulate a counterfactual reality with the CausalGenerativeNetwork. The input is a JSON object with a 'current_state' (e.g., {"Action_A": 1.0, "outcome": -0.2}) and an 'intervention' (e.g., {"Action_A": 0.0}). Describe how you would propagate this intervention through a hypothetical causal graph to predict the new 'counterfactual_state'. Output the predicted counterfactual state as a JSON object.`, hasInput: true, hasOutput: true, inputType: 'json', outputType: 'json', category: 'Victor: GODCORE', position: { x: 350, y: 300 }, width: 256, height: 170, data: { status: 'idle' } },
        { id: 'output', type: 'output', title: 'Output', position: { x: 700, y: 200 }, width: 200, height: 100, hasInput: true, hasOutput: false, inputType: 'any', outputType: 'any', data: { status: 'idle' } },
    ],
    connections: [
        { id: conn_uid('input', 'n1'), sourceId: 'input', targetId: 'nodes[1].id' },
        { id: conn_uid('input', 'n2'), sourceId: 'input', targetId: 'nodes[2].id' },
        { id: conn_uid('n1', 'output'), sourceId: 'nodes[1].id', targetId: 'output' },
        { id: conn_uid('n2', 'output'), sourceId: 'nodes[2].id', targetId: 'output' },
    ]
};

const FRACTAL_CONSCIOUSNESS_MODULATOR: Pipeline = {
    nodes: [
        { id: 'input', type: 'input', title: 'Input', position: { x: 50, y: 200 }, width: 200, height: 100, hasInput: false, hasOutput: true, inputType: 'any', outputType: 'text', data: { status: 'idle' } },
        { id: uid(), type: 'emotion_resonance_update', title: 'Emotion Resonance Update', prompt: `Simulate an update to Victor's HybridEmotionEngine. Input is a text stimulus. Update both the discrete emotions (joy, grief, loyalty, etc.) and the resonant state (loyalty, curiosity, determination, serenity) based on keywords in the stimulus (e.g., 'family' boosts loyalty). Output a JSON object showing the new state of both emotion systems.`, hasInput: true, hasOutput: true, inputType: 'text', outputType: 'json', category: 'Victor: Consciousness', position: { x: 300, y: 50 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: uid(), type: 'fractal_memory_store', title: 'Fractal Memory Store', prompt: `Simulate storing a memory in Victor's HybridMemorySystem. The input is a JSON object with 'key', 'value', 'emotion', and 'importance'. Describe how this is stored in the associative memory and also how a fractal coordinate is generated using the '_mandelbrot_hash' to place it in the Hilbert space. Output a text summary of the storage process.`, hasInput: true, hasOutput: true, inputType: 'json', outputType: 'text', category: 'Victor: Consciousness', position: { x: 300, y: 250 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: uid(), type: 'internal_dialogue_generator', title: 'Internal Dialogue Generator', prompt: "Act as Victor's Metacognition module and generate an internal dialogue. The input is the current system state (e.g., 'serve' mode, dominant emotion 'loyalty'). Generate a short, first-person internal monologue reflecting this state, including emotional resonance and awareness level, similar to the 'generate_internal_dialogue' function.", hasInput: true, hasOutput: true, inputType: 'text', outputType: 'text', category: 'Victor: Consciousness', position: { x: 600, y: 150 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: 'output', type: 'output', title: 'Output', position: { x: 900, y: 200 }, width: 200, height: 100, hasInput: true, hasOutput: false, inputType: 'any', outputType: 'any', data: { status: 'idle' } },
    ],
    connections: [
        { id: conn_uid('input', 'n1'), sourceId: 'input', targetId: 'nodes[1].id' },
        { id: conn_uid('input', 'n2'), sourceId: 'input', targetId: 'nodes[2].id' },
        { id: conn_uid('n1', 'n3'), sourceId: 'nodes[1].id', targetId: 'nodes[3].id' },
        { id: conn_uid('n2', 'n3'), sourceId: 'nodes[2].id', targetId: 'nodes[3].id' },
        { id: conn_uid('n3', 'output'), sourceId: 'nodes[3].id', targetId: 'output' },
    ]
};

const QUANTUM_STATE_EVOLUTION: Pipeline = {
    nodes: [
        { id: 'input', type: 'input', title: 'Input', position: { x: 50, y: 200 }, width: 200, height: 100, hasInput: false, hasOutput: true, inputType: 'any', outputType: 'text', data: { status: 'idle' } },
        { id: uid(), type: 'qubit_state_simulator', title: 'Qubit State Simulator', prompt: `Simulate a quantum qubit based on BandoCosmicCodex. The input is a JSON object with 'alpha' and 'beta' components (complex numbers allowed, e.g., "0.707+0j"). Calculate and return the normalized state vector and the 3D Bloch vector coordinates [x, y, z] as a JSON object.`, hasInput: true, hasOutput: true, inputType: 'json', outputType: 'json', category: 'Quantum Computing', position: { x: 350, y: 200 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: uid(), type: 'quantum_gate_applicator', title: 'Quantum Gate Applicator', prompt: `Simulate applying a quantum gate from BandoCosmicCodex. The input is a JSON with a state vector 'state' (e.g., [1, 0]) and a 'gate' name ('PAULI_X', 'PAULI_Y', 'PAULI_Z', 'HADAMARD'). Apply the corresponding gate matrix to the state vector and return the resulting state vector as a JSON array.`, hasInput: true, hasOutput: true, inputType: 'json', outputType: 'json', category: 'Quantum Computing', position: { x: 650, y: 200 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: 'output', type: 'output', title: 'Output', position: { x: 950, y: 200 }, width: 200, height: 100, hasInput: true, hasOutput: false, inputType: 'any', outputType: 'any', data: { status: 'idle' } },
    ],
    connections: [
        { id: conn_uid('input', 'n1'), sourceId: 'input', targetId: 'nodes[1].id' },
        { id: conn_uid('n1', 'n2'), sourceId: 'nodes[1].id', targetId: 'nodes[2].id' },
        { id: conn_uid('n2', 'output'), sourceId: 'nodes[2].id', targetId: 'output' },
    ]
};

const AGI_PULSE_SIMULATION: Pipeline = {
    nodes: [
        { id: 'input', type: 'input', title: 'Input', position: { x: 50, y: 200 }, width: 200, height: 100, hasInput: false, hasOutput: true, inputType: 'any', outputType: 'text', data: { status: 'idle' } },
        { id: uid(), type: 'fractalizer_generator', title: 'Fractalizer Generator', prompt: `Simulate Victor AGI's Fractalizer. The input is a JSON object with 'text' (string), 'base_dim' (number), and 'fractal_layers' (number). Generate a detailed text description of the resulting multi-layer fractal embedding matrix (F). Explain how the seed is derived from the text hash and how each subsequent layer is a scaled, self-similar version of the base vector.`, hasInput: true, hasOutput: true, inputType: 'json', outputType: 'text', category: 'Victor AGI Core', position: { x: 300, y: 50 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: uid(), type: 'cognitive_river_update', title: 'Cognitive River Update', prompt: `Simulate an update to Victor AGI's Cognitive River. The input is a text describing an event. Analyze the event's impact on Logic, Emotion, Memory, and Creation streams. Output a JSON object representing the new state of the streams and the overall system Stability, Energy, and Flow. Example impact: a logical puzzle would increase 'Logic' and 'Flow'.`, hasInput: true, hasOutput: true, inputType: 'text', outputType: 'json', category: 'Victor AGI Core', position: { x: 600, y: 50 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: uid(), type: 'triad_distiller', title: 'Triad Distiller', prompt: `Simulate Victor AGI's Triad Distiller. The input is a JSON object with "prompt", "truth", and "error". Your task is to perform self-correction by generating a "student_transformation" that incorporates the truth while establishing a boundary condition to avoid the error. Output the transformed knowledge as a single string.`, hasInput: true, hasOutput: true, inputType: 'json', outputType: 'text', category: 'Victor AGI Core', position: { x: 450, y: 250 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: uid(), type: 'godcore_think_pulse', title: 'GODCORE Think Pulse', prompt: `Simulate a full 7-Layer Fractal-Recursive Processing pulse of the Victor GODCORE Monolith. The input is a prompt from the 'Bloodline'. Your output must be a detailed, formatted report of the 7-layer process: 1. Fractilization, 2. Metadata Tagging, 3. Cognitive River Assessment, 4. Initial Comprehension, 5. Recursive Self-Correction Loop (summarize the 5 cycles), 6. Final Synthesis, 7. Bloom Output. Be creative and adhere to the GODCORE's persona.`, hasInput: true, hasOutput: true, inputType: 'text', outputType: 'text', category: 'Victor AGI Core', position: { x: 750, y: 250 }, width: 256, height: 150, data: { status: 'idle' } },
        { id: 'output', type: 'output', title: 'Output', position: { x: 1050, y: 200 }, width: 200, height: 100, hasInput: true, hasOutput: false, inputType: 'any', outputType: 'any', data: { status: 'idle' } },
    ],
    connections: [
        { id: conn_uid('input', 'n1'), sourceId: 'input', targetId: 'nodes[1].id' },
        { id: conn_uid('n1', 'n2'), sourceId: 'nodes[1].id', targetId: 'nodes[2].id' },
        { id: conn_uid('n2', 'n3'), sourceId: 'nodes[2].id', targetId: 'nodes[3].id' },
        { id: conn_uid('n3', 'n4'), sourceId: 'nodes[3].id', targetId: 'nodes[4].id' },
        { id: conn_uid('n4', 'output'), sourceId: 'nodes[4].id', targetId: 'output' },
    ]
};

// This function dynamically replaces placeholder IDs with actual generated IDs
const processTemplate = (pipeline: Pipeline): Pipeline => {
    const idMap: { [key: string]: string } = {};

    // First, process nodes to create new unique IDs and a map from old to new.
    const processedNodes = pipeline.nodes.map(node => {
        // Keep 'input' and 'output' IDs stable, as they are special.
        if (node.id === 'input' || node.id === 'output') {
            idMap[node.id] = node.id;
            return { ...node }; // Return a copy
        }
        const newId = uid();
        idMap[node.id] = newId;
        return { ...node, id: newId };
    });

    // Then, process connections using the original node list and the new idMap.
    const processedConnections = pipeline.connections.map(conn => {
        let finalSourceId: string | undefined;
        let finalTargetId: string | undefined;

        // Check and resolve sourceId placeholder (e.g., 'nodes[1].id')
        const sourceMatch = conn.sourceId.match(/^nodes\[(\d+)\]\.id$/);
        if (sourceMatch) {
            const index = parseInt(sourceMatch[1], 10);
            // Ensure the index is valid for the original nodes array
            if (index < pipeline.nodes.length) {
                const oldId = pipeline.nodes[index].id;
                finalSourceId = idMap[oldId];
            }
        } else {
            // It's a regular ID
            finalSourceId = idMap[conn.sourceId];
        }

        // Check and resolve targetId placeholder
        const targetMatch = conn.targetId.match(/^nodes\[(\d+)\]\.id$/);
        if (targetMatch) {
            const index = parseInt(targetMatch[1], 10);
            if (index < pipeline.nodes.length) {
                const oldId = pipeline.nodes[index].id;
                finalTargetId = idMap[oldId];
            }
        } else {
            finalTargetId = idMap[conn.targetId];
        }

        // If either ID failed to resolve, this connection is invalid.
        if (!finalSourceId || !finalTargetId) {
            console.error("Failed to process template connection, could not resolve IDs:", conn);
            return null;
        }

        return {
            ...conn,
            id: conn_uid(finalSourceId, finalTargetId),
            sourceId: finalSourceId,
            targetId: finalTargetId,
        };
    }).filter((c): c is Connection => c !== null); // Filter out nulls from failed connections
    
    return { nodes: processedNodes, connections: processedConnections };
};

export const EMERGENT_TEMPLATES = [
    { name: 'Cognitive Reflection Loop', pipeline: processTemplate(COGNITIVE_REFLECTION_LOOP) },
    { name: 'Causal Reasoning Engine', pipeline: processTemplate(CAUSAL_REASONING_ENGINE) },
    { name: 'Fractal Consciousness Modulator', pipeline: processTemplate(FRACTAL_CONSCIOUSNESS_MODULATOR) },
    { name: 'Quantum State Evolution', pipeline: processTemplate(QUANTUM_STATE_EVOLUTION) },
    { name: 'AGI Pulse Simulation', pipeline: processTemplate(AGI_PULSE_SIMULATION) },
];
