
import React, { useState, useCallback, useRef, MouseEvent, DragEvent, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Node from './components/Node';
import Group from './components/Group';
import ControlPanel from './components/ControlPanel';
import IOPanel from './components/IOPanel';
import { AINode, Connection, NodeTemplate, Pipeline, ExecutionLogEntry, EmergenceLog, Group as GroupType } from './types';
import { PREDEFINED_MODULES } from './services/moduleLoader';
import { runPrompt, summarizeTransformation, analyzeSystemEmergence } from './services/geminiService';
import { useAIFactory } from './hooks/useAIFactory';
import { SpinnerIcon } from './components/icons';
import { EMERGENT_TEMPLATES } from './services/templateLoader';

// Simple unique ID generator
const uid = () => `id_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

const initialNodes: AINode[] = [
  {
    id: 'input',
    type: 'input',
    title: 'Input',
    position: { x: 50, y: 200 },
    width: 200,
    height: 100,
    hasInput: false,
    hasOutput: true,
    inputType: 'any',
    outputType: 'text',
    data: { status: 'idle' },
  },
  {
    id: 'output',
    type: 'output',
    title: 'Output',
    position: { x: 800, y: 200 },
    width: 200,
    height: 100,
    hasInput: true,
    hasOutput: false,
    inputType: 'any',
    outputType: 'any',
    data: { status: 'idle' },
  },
];

const App: React.FC = () => {
  const [nodes, setNodes] = useState<AINode[]>(initialNodes);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [groups, setGroups] = useState<GroupType[]>([]);
  const [pipelineInput, setPipelineInput] = useState<string>('');
  const [pipelineOutput, setPipelineOutput] = useState<string>('');
  const [isRunning, setIsRunning] = useState(false);
  const [executionLog, setExecutionLog] = useState<ExecutionLogEntry[]>([]);
  const [emergenceLog, setEmergenceLog] = useState<EmergenceLog | null>(null);

  const [customNodeTemplates, setCustomNodeTemplates] = useState<NodeTemplate[]>([]);

  // Interaction states
  const [draggingElement, setDraggingElement] = useState<{id: string, type: 'node' | 'group'} | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const canvasRef = useRef<HTMLDivElement>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Connection states
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectionStart, setConnectionStart] = useState<{ nodeId: string; pos: { x: number; y: number } } | null>(null);
  const [connectionEnd, setConnectionEnd] = useState<{ x: number; y: number } | null>(null);

  // Resizing state
  const [resizingNode, setResizingNode] = useState<{ nodeId: string, initialPos: {x: number, y: number}, initialSize: {width: number, height: number} } | null>(null);

  // AI Factory Modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [aiDescription, setAiDescription] = useState('');
  const { isCreating, error: createError, createNewModule } = useAIFactory();


  // --- Node & Connection Management ---
  const addNode = (template: NodeTemplate, position: { x: number; y: number }) => {
    const newNode: AINode = {
      ...template,
      id: uid(),
      position,
      data: { status: 'idle' },
    };
    setNodes((nds) => [...nds, newNode]);
  };

  const deleteElement = (id: string) => {
    const isGroup = groups.some(g => g.id === id);
    if (isGroup) {
      const group = groups.find(g => g.id === id)!;
      setNodes(nds => nds.map(n => n.groupId === id ? {...n, groupId: undefined} : n));
      setGroups(grps => grps.filter(g => g.id !== id));
    } else {
      setNodes((nds) => nds.filter((node) => node.id !== id));
      setConnections((conns) => conns.filter((conn) => conn.sourceId !== id && conn.targetId !== id));
    }
    setSelectedIds(ids => ids.filter(selectedId => selectedId !== id));
  };

  const updateNodeData = (nodeId: string, data: Partial<AINode['data']>) => {
    setNodes((nds) =>
      nds.map((node) =>
        node.id === nodeId ? { ...node, data: { ...node.data, ...data } } : node
      )
    );
  };
  
  const updateNodeSize = (nodeId: string, width: number, height: number) => {
    setNodes(nds => nds.map(n => n.id === nodeId ? {...n, width, height} : n));
  }


  // --- Drag and Drop ---
  const handleDragOver = (event: DragEvent) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (event: DragEvent) => {
    event.preventDefault();
    const templateString = event.dataTransfer.getData('application/json');
    if (!templateString || !canvasRef.current) return;

    const template: NodeTemplate = JSON.parse(templateString);
    const canvasBounds = canvasRef.current.getBoundingClientRect();
    const position = {
      x: event.clientX - canvasBounds.left - 128, // center node on drop
      y: event.clientY - canvasBounds.top - 75,
    };
    addNode(template, position);
  };

  const handleElementMouseDown = (e: MouseEvent, id: string, type: 'node' | 'group') => {
    if (isConnecting) return;
    const target = e.target as HTMLElement;
    if (!target.classList.contains('grab-handle')) return;

    setDraggingElement({id, type});
    
    if (type === 'node') {
        const node = nodes.find(n => n.id === id)!;
        setDragOffset({ x: e.clientX - node.position.x, y: e.clientY - node.position.y });
    } else {
        const group = groups.find(g => g.id === id)!;
        setDragOffset({ x: e.clientX - group.position.x, y: e.clientY - group.position.y });
    }
  };

  const handleElementClick = (e: MouseEvent, id: string) => {
      e.stopPropagation();
      const target = e.target as HTMLElement;
      if (target.closest('button, [data-handle-type]')) return; // Ignore clicks on buttons or handles
      
      if (e.shiftKey) {
          setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
      } else {
          setSelectedIds([id]);
      }
  };

  const handleResizeStart = (e: MouseEvent, nodeId: string) => {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return;
    setResizingNode({
        nodeId,
        initialPos: { x: e.clientX, y: e.clientY },
        initialSize: { width: node.width || 256, height: node.height || 150 },
    });
  };

  // --- Mouse Move Handler for multiple interactions ---
  const handleMouseMove = useCallback((e: globalThis.MouseEvent) => {
    if (draggingElement) {
        if(draggingElement.type === 'node') {
            const node = nodes.find(n => n.id === draggingElement.id)!;
            const newX = e.clientX - dragOffset.x;
            const newY = e.clientY - dragOffset.y;
            setNodes(nds => nds.map(n => n.id === draggingElement.id ? { ...n, position: { x: newX, y: newY } } : n));
        } else if (draggingElement.type === 'group') {
            const group = groups.find(g => g.id === draggingElement.id)!;
            const groupOrigPos = group.position;
            const newX = e.clientX - dragOffset.x;
            const newY = e.clientY - dragOffset.y;
            const dx = newX - groupOrigPos.x;
            const dy = newY - groupOrigPos.y;
            
            setGroups(grps => grps.map(g => g.id === draggingElement.id ? {...g, position: {x: newX, y: newY}} : g));
            setNodes(nds => nds.map(n => group.childNodeIds.includes(n.id) ? {...n, position: {x: n.position.x + dx, y: n.position.y + dy}} : n));
        }
    } else if (isConnecting && connectionStart) {
      if (!canvasRef.current) return;
      const bounds = canvasRef.current.getBoundingClientRect();
      setConnectionEnd({ x: e.clientX - bounds.left, y: e.clientY - bounds.top });
    } else if (resizingNode) {
      const dx = e.clientX - resizingNode.initialPos.x;
      const dy = e.clientY - resizingNode.initialPos.y;
      const newWidth = Math.max(200, resizingNode.initialSize.width + dx);
      const newHeight = Math.max(120, resizingNode.initialSize.height + dy);
      updateNodeSize(resizingNode.nodeId, newWidth, newHeight);
    }
  }, [draggingElement, dragOffset, isConnecting, connectionStart, resizingNode, nodes, groups]);

  const handleMouseUp = useCallback(() => {
    setDraggingElement(null);
    setIsConnecting(false);
    setConnectionStart(null);
    setConnectionEnd(null);
    setResizingNode(null);
  }, []);

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [handleMouseMove, handleMouseUp]);


  // --- Connection Logic ---
  const handleHandleMouseDown = (e: MouseEvent) => {
    e.stopPropagation();
    const target = e.target as HTMLElement;
    const handleType = target.dataset.handleType;
    const nodeId = target.dataset.nodeId;

    if (handleType === 'source' && nodeId) {
      setIsConnecting(true);
      const pos = getEffectiveHandlePosition(nodeId, 'source');
      setConnectionStart({ nodeId, pos });
      setConnectionEnd(pos);
    }
  };

  const handleHandleMouseUp = (e: MouseEvent) => {
    const target = e.target as HTMLElement;
    const handleType = target.dataset.handleType;
    const nodeId = target.dataset.nodeId;

    if (isConnecting && connectionStart && handleType === 'target' && nodeId) {
      if (connectionStart.nodeId === nodeId) return;
      const exists = connections.some(c => c.sourceId === connectionStart.nodeId && c.targetId === nodeId);
      if (exists) return;
      
      const newConnection: Connection = {
        id: `conn_${connectionStart.nodeId}_${nodeId}`,
        sourceId: connectionStart.nodeId,
        targetId: nodeId,
      };
      setConnections((conns) => [...conns, newConnection]);
    }
  };

  const getEffectiveHandlePosition = (nodeId: string, type: 'source' | 'target') => {
    const node = nodes.find(n => n.id === nodeId);
    if (!node) return { x: 0, y: 0 };

    if(node.groupId) {
        const group = groups.find(g => g.id === node.groupId);
        if(group?.isCollapsed) {
            return {
                x: group.position.x + (type === 'source' ? group.width : 0),
                y: group.position.y + group.height / 2,
            }
        }
    }

    const x = type === 'source' ? node.position.x + (node.width || 256) : node.position.x;
    const y = node.position.y + (node.height || 150) / 2;
    return { x, y };
  };

  // --- Grouping Logic ---
  const handleGroupSelection = () => {
    const selectedNodes = nodes.filter(n => selectedIds.includes(n.id) && !n.groupId);
    if (selectedNodes.length < 2) return;

    const childNodeIds = selectedNodes.map(n => n.id);
    const x1 = Math.min(...selectedNodes.map(n => n.position.x));
    const y1 = Math.min(...selectedNodes.map(n => n.position.y));
    const x2 = Math.max(...selectedNodes.map(n => n.position.x + (n.width || 256)));
    const y2 = Math.max(...selectedNodes.map(n => n.position.y + (n.height || 150)));

    const padding = 40;
    const newGroup: GroupType = {
        id: uid(),
        title: 'New Group',
        position: { x: x1 - padding, y: y1 - padding },
        width: x2 - x1 + padding * 2,
        height: y2 - y1 + padding * 2,
        childNodeIds,
        isCollapsed: false,
    };

    setGroups(prev => [...prev, newGroup]);
    setNodes(nds => nds.map(n => childNodeIds.includes(n.id) ? {...n, groupId: newGroup.id} : n));
    setSelectedIds([newGroup.id]);
  };
  
  const handleUngroup = () => {
    const group = groups.find(g => g.id === selectedIds[0]);
    if (!group) return;
    setNodes(nds => nds.map(n => n.groupId === group.id ? {...n, groupId: undefined} : n));
    setGroups(grps => grps.filter(g => g.id !== group.id));
    setSelectedIds(group.childNodeIds);
  };
  
  const handleToggleCollapse = (groupId: string) => {
    setGroups(grps => grps.map(g => g.id === groupId ? {...g, isCollapsed: !g.isCollapsed} : g));
  };


  // --- Pipeline Execution ---
  const runPipeline = async () => {
    setIsRunning(true);
    setPipelineOutput('');
    setExecutionLog([]);
    setEmergenceLog(null);
    setNodes(nds => nds.map(n => ({ ...n, data: { ...n.data, status: 'idle', error: undefined, output: undefined } })));
    const adj: { [key: string]: string[] } = {};
    const inDegree: { [key:string]: number } = {};
    nodes.forEach(node => { adj[node.id] = []; inDegree[node.id] = 0; });
    connections.forEach(conn => { adj[conn.sourceId].push(conn.targetId); inDegree[conn.targetId]++; });
    const queue = nodes.filter(node => inDegree[node.id] === 0).map(n => n.id);
    const executionOrder: string[] = [];
    while (queue.length > 0) {
        const u = queue.shift()!;
        executionOrder.push(u);
        adj[u].forEach(v => { inDegree[v]--; if (inDegree[v] === 0) queue.push(v); });
    }
    if (executionOrder.length !== nodes.length) {
      setPipelineOutput("Error: Cycle detected in the graph. Cannot execute.");
      setNodes(nds => nds.map(n => ({...n, data: {...n.data, status: 'error', error: 'Cycle detected'}})));
      setIsRunning(false);
      return;
    }
    const nodeOutputs: { [key: string]: any } = { 'input': pipelineInput };
    const newExecutionLog: ExecutionLogEntry[] = [];
    for (const nodeId of executionOrder) {
        const node = nodes.find(n => n.id === nodeId)!;
        if(node.type === 'output') continue;
        updateNodeData(nodeId, { status: 'running' });
        const incomingConnections = connections.filter(c => c.targetId === nodeId);
        const input = node.type === 'input' ? pipelineInput : incomingConnections.map(c => nodeOutputs[c.sourceId]).join('\n');
        try {
            let output: any;
            if (node.type === 'input') output = pipelineInput;
            else {
                const inputText = typeof input === 'object' ? JSON.stringify(input, null, 2) : input;
                output = await runPrompt(node.prompt!, inputText);
                if (node.outputType === 'json') {
                    try { output = JSON.parse(output); } 
                    catch { console.warn(`Node ${node.id} expected JSON but got invalid format. Passing as text.`); }
                }
            }
            nodeOutputs[nodeId] = output;
            updateNodeData(nodeId, { status: 'success', output });
            const summary = await summarizeTransformation(node.title, node.prompt || '', input, output);
            newExecutionLog.push({ step: newExecutionLog.length + 1, nodeId, nodeTitle: node.title, summary, input, output });
        } catch (e: any) {
            updateNodeData(nodeId, { status: 'error', error: e.message });
            setPipelineOutput(`Error at node ${node.title}: ${e.message}`);
            setIsRunning(false);
            return;
        }
    }
    const finalOutputNodeId = 'output';
    const finalConnections = connections.filter(c => c.targetId === finalOutputNodeId);
    const finalOutput = finalConnections.map(c => {
      const output = nodeOutputs[c.sourceId];
      return typeof output === 'object' ? JSON.stringify(output, null, 2) : String(output);
    }).join('\n');
    updateNodeData(finalOutputNodeId, { status: 'success' });
    setPipelineOutput(finalOutput);
    setExecutionLog(newExecutionLog);
    const executionTitles = executionOrder.map(id => nodes.find(n => n.id === id)?.title).filter((t): t is string => !!t);
    const emergenceSummary = await analyzeSystemEmergence(executionTitles);
    setEmergenceLog({ executionOrder: executionTitles, emergenceSummary });
    setIsRunning(false);
  };
  
  // --- Save/Load & Template Logic ---
  const handleSave = () => {
    const pipeline: Pipeline = { nodes, connections, groups, executionLog, emergenceLog: emergenceLog || undefined };
    const dataStr = JSON.stringify(pipeline, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'bando-fi-pipeline.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleLoad = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const result = e.target?.result;
            if (typeof result === 'string') {
                if (window.confirm('Loading a new project will clear the current canvas. Are you sure?')) {
                    const pipeline: Pipeline = JSON.parse(result);
                    setNodes(pipeline.nodes);
                    setConnections(pipeline.connections);
                    setGroups(pipeline.groups || []);
                    setExecutionLog(pipeline.executionLog || []);
                    setEmergenceLog(pipeline.emergenceLog || null);
                    setPipelineInput(''); setPipelineOutput(''); setSelectedIds([]);
                }
            }
        } catch (error) { alert('Failed to load pipeline: Invalid file format.'); }
    };
    reader.readAsText(file);
    event.target.value = '';
  };
  
  const handleLoadTemplate = (pipeline: Pipeline) => {
    if (window.confirm('Loading a template will clear the current canvas. Are you sure?')) {
        setNodes(pipeline.nodes);
        setConnections(pipeline.connections);
        setGroups(pipeline.groups || []);
        setPipelineInput(''); setPipelineOutput(''); setExecutionLog([]); setEmergenceLog(null); setSelectedIds([]);
    }
  };

  const handleClear = () => {
    if (window.confirm('Are you sure you want to clear the entire canvas?')) {
        setNodes(initialNodes);
        setConnections([]);
        setGroups([]);
        setPipelineInput(''); setPipelineOutput(''); setExecutionLog([]); setEmergenceLog(null); setSelectedIds([]);
    }
  };
  
  const handleDownloadEmergenceLog = () => {
    if (!emergenceLog) return;
    const dataStr = JSON.stringify(emergenceLog, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = 'bando-fi-emergence-log.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  const handleDownloadReport = () => {
    const report: Pipeline = { nodes, connections, groups, executionLog, emergenceLog: emergenceLog || undefined };
    const dataStr = JSON.stringify(report, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = 'bando-fi-report.json';
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  // --- AI Module Creation ---
  const handleCreateModule = async () => {
    if (!aiDescription) return;
    const newModule = await createNewModule(aiDescription);
    if (newModule) {
        setCustomNodeTemplates(prev => [...prev, newModule]);
        setIsCreateModalOpen(false);
        setAiDescription('');
    }
  };


  return (
    <div className="w-screen h-screen bg-gray-900 text-white font-sans overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
        
      <Sidebar
        onDragStart={(event, template) => event.dataTransfer.setData('application/json', JSON.stringify(template))}
        nodeTemplates={customNodeTemplates}
        onOpenCreateModal={() => setIsCreateModalOpen(true)}
      />

      <main className="w-full h-full pl-64">
        <div 
            ref={canvasRef} 
            className="relative w-full h-full"
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onMouseDown={(e: MouseEvent<HTMLDivElement>) => {
              if (e.target === canvasRef.current) setSelectedIds([]);
              const target = e.target as HTMLElement;
              if (target.dataset.handleType) handleHandleMouseDown(e);
            }}
            onMouseUp={(e: MouseEvent<HTMLDivElement>) => {
              const target = e.target as HTMLElement;
              if (target.dataset.handleType) handleHandleMouseUp(e);
            }}
        >
          <svg className="absolute top-0 left-0 w-full h-full pointer-events-none z-0">
            {connections.map((conn) => {
                const sourcePos = getEffectiveHandlePosition(conn.sourceId, 'source');
                const targetPos = getEffectiveHandlePosition(conn.targetId, 'target');
                const d = `M ${sourcePos.x} ${sourcePos.y} C ${sourcePos.x + 100} ${sourcePos.y}, ${targetPos.x - 100} ${targetPos.y}, ${targetPos.x} ${targetPos.y}`;
                return <path key={conn.id} d={d} stroke="#4ade80" strokeWidth="2" fill="none" />;
            })}
            {isConnecting && connectionStart && connectionEnd && (
                <path d={`M ${connectionStart.pos.x} ${connectionStart.pos.y} C ${connectionStart.pos.x + 100} ${connectionStart.pos.y}, ${connectionEnd.x - 100} ${connectionEnd.y}, ${connectionEnd.x} ${connectionEnd.y}`} 
                    stroke="#f472b6" strokeWidth="2" fill="none" strokeDasharray="5,5" />
            )}
          </svg>
          
          {groups.map((group) => (
            <div key={group.id} onMouseDown={(e) => handleElementMouseDown(e, group.id, 'group')} onClick={(e) => handleElementClick(e, group.id)}>
              <Group
                group={group}
                isSelected={selectedIds.includes(group.id)}
                onToggleCollapse={handleToggleCollapse}
                onDelete={deleteElement}
              >
                  {nodes.filter(n => n.groupId === group.id).map(node => (
                     <div key={node.id} onMouseDown={(e) => handleElementMouseDown(e, node.id, 'node')} onClick={(e) => handleElementClick(e, node.id)}>
                        <Node node={node} isSelected={selectedIds.includes(node.id)} onDelete={deleteElement} onUpdateData={updateNodeData} onResizeStart={handleResizeStart} />
                     </div>
                  ))}
              </Group>
            </div>
          ))}
          
          {nodes.filter(n => !n.groupId).map((node) => (
            <div key={node.id} onMouseDown={(e) => handleElementMouseDown(e, node.id, 'node')} onClick={(e) => handleElementClick(e, node.id)} style={{zIndex: 1}}>
              <Node node={node} isSelected={selectedIds.includes(node.id)} onDelete={deleteElement} onUpdateData={updateNodeData} onResizeStart={handleResizeStart} />
            </div>
          ))}
        </div>
      </main>

      <ControlPanel 
        onRun={runPipeline}
        onSave={handleSave}
        onLoad={handleLoad}
        onClear={handleClear}
        onGroup={handleGroupSelection}
        onUngroup={handleUngroup}
        onDownloadReport={handleDownloadReport}
        isRunning={isRunning}
        templates={EMERGENT_TEMPLATES}
        onLoadTemplate={handleLoadTemplate}
        selectedIds={selectedIds}
        groups={groups}
      />
      <IOPanel 
        input={pipelineInput} setInput={setPipelineInput} output={pipelineOutput} isRunning={isRunning}
        executionLog={executionLog} emergenceLog={emergenceLog} onDownloadEmergenceLog={handleDownloadEmergenceLog}
      />

      {isCreateModalOpen && (
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center">
            <div className="bg-gray-900 border-2 border-green-500/50 rounded-lg shadow-2xl p-6 w-full max-w-lg font-orbitron">
                <h2 className="text-2xl font-bold mb-4 text-green-400 text-glow-green">Create Custom Module</h2>
                <p className="text-sm text-gray-400 mb-4">Describe the task you want the new module to perform. Be specific for the best results.</p>
                <textarea
                    value={aiDescription} onChange={(e) => setAiDescription(e.target.value)}
                    placeholder="e.g., 'Translate English text to Pirate speech' or 'Extract all email addresses from a block of text'"
                    className="w-full h-32 p-2 bg-gray-800 border border-gray-700 rounded-md text-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors mb-4"
                    disabled={isCreating}
                />
                {createError && <p className="text-red-500 text-sm mb-4">Error: {createError}</p>}
                <div className="flex justify-end gap-4">
                    <button onClick={() => setIsCreateModalOpen(false)}
                        className="px-4 py-2 rounded-md font-semibold text-sm bg-gray-600 hover:bg-gray-500 text-white transition-colors"
                        disabled={isCreating}>Cancel</button>
                    <button onClick={handleCreateModule}
                        className="px-4 py-2 rounded-md font-semibold text-sm bg-green-600 hover:bg-green-500 text-white shadow-[0_0_10px_#00ff00] flex items-center gap-2"
                        disabled={isCreating || !aiDescription}>
                        {isCreating ? <SpinnerIcon /> : null} {isCreating ? 'Creating...' : 'Create'}</button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default App;