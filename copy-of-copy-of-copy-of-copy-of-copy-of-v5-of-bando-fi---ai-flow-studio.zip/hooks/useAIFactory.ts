import { useState } from 'react';
import { createModule } from '../services/geminiService';
import type { NodeTemplate } from '../types';

export const useAIFactory = () => {
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createNewModule = async (description: string): Promise<NodeTemplate | null> => {
    setIsCreating(true);
    setError(null);
    try {
      const newModule = await createModule(description);
      return newModule;
    } catch (err) {
      console.error("Failed to create module:", err);
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
      return null;
    } finally {
      setIsCreating(false);
    }
  };

  return { isCreating, error, createNewModule };
};
