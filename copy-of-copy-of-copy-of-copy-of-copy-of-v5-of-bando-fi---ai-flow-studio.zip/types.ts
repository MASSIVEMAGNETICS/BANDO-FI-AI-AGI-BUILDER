// Defines the types of data that can flow between nodes.
export type SocketType = 'text' | 'json' | 'any';

// Represents the execution status of a node in the pipeline.
export type NodeStatus = 'idle' | 'running' | 'success' | 'error';

// Contains the dynamic data for a node, including its status and I/O values.
export interface NodeData {
  status: NodeStatus;
  input?: any;
  output?: any;
  error?: string;
  [key: string]: any;
}

// Represents a node on the canvas in the AI pipeline.
export interface AINode {
  id: string;
  type: string;
  title: string;
  position: { x: number; y: number };
  width?: number;
  height?: number;
  groupId?: string; // ID of the group this node belongs to
  
  // Properties from the template
  prompt?: string;
  hasInput: boolean;
  hasOutput: boolean;
  inputType: SocketType;
  outputType: SocketType;
  // FIX: Add optional 'category' property to the AINode interface.
  category?: string;
  
  // Dynamic data during execution
  data: NodeData;
}

// Represents a group of nodes.
export interface Group {
  id: string;
  title: string;
  position: { x: number; y: number };
  width: number;
  height: number;
  childNodeIds: string[];
  isCollapsed: boolean;
}

// Defines the structure for a reusable module template.
export interface NodeTemplate {
    type: string;
    title: string;
    prompt?: string;
    hasInput: boolean;
    hasOutput:boolean;
    inputType: SocketType;
    outputType: SocketType;
    category: string;
}

// Represents a connection (an edge) between two nodes.
export interface Connection {
    id: string;
    sourceId: string;
    targetId: string;
}

// Represents a single step in the pipeline's execution history.
export interface ExecutionLogEntry {
  step: number;
  nodeId: string;
  nodeTitle: string;
  summary: string;
  input: any;
  output: any;
}

// Represents the high-level analysis of the entire pipeline's function.
export interface EmergenceLog {
  executionOrder: string[];
  emergenceSummary: string;
}

// Represents the entire state of the pipeline for saving and loading.
export interface Pipeline {
    nodes: AINode[];
    connections: Connection[];
    groups?: Group[];
    executionLog?: ExecutionLogEntry[];
    emergenceLog?: EmergenceLog;
}